import React from "react";

const CustomButton = () => {
  return <div>CustomButton</div>;
};

export default CustomButton;
